﻿Imports System.IO

Public Class Form1

    Private Sub Form1_Activated(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Activated

        If CheckBox4.Checked = False Then
            '----------------< Do nothing >----------------------
        ElseIf CheckBox4.Checked = True Then
            '----------------< Close CMD if it lose the focus >----------------------
            For Each P As Process In System.Diagnostics.Process.GetProcessesByName("cmd")
                If P.MainWindowTitle.Contains("C:\Windows") Then
                    P.Kill()
                End If
            Next
            For Each P As Process In System.Diagnostics.Process.GetProcessesByName("qrcp")
                P.Kill()
            Next
        End If

    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        '----------------< Create options file if not exist >----------------------
        If Not System.IO.File.Exists(Application.StartupPath & "\options.ini") Then                       'if options file not exist
            File.Create(Application.StartupPath & "\options.ini").Dispose()                               'create options file
            Dim createText() As String = {"not_zip", "not_alive", "C:\qrcp_download", "max_style", "dont_kill"}                                           ' write empty lines in options file
            System.IO.File.WriteAllLines(Application.StartupPath & "\options.ini", createText)
        End If

        '----------------< Load options file >----------------------
        Dim Lines() As String = System.IO.File.ReadAllLines(Application.StartupPath & "\options.ini")

        If Lines(0) = "not_zip" Then CheckBox1.Checked = False
        If Lines(0) <> "not_zip" Then CheckBox1.Checked = True

        If Lines(1) = "not_alive" Then CheckBox2.Checked = False
        If Lines(1) <> "not_alive" Then CheckBox2.Checked = True

        If Lines(2) = "" Then TextBox1.Text = "C:\qrcp_download"
        If Lines(2) <> "" Then TextBox1.Text = Lines(2)

        If Lines(3) = "max_style" Then
            GroupBox1.Visible = True
            GroupBox2.Visible = True
            GroupBox3.Visible = True

            DataGridView1.Top = 138
            DataGridView1.Height = 212

            CheckBox3.Checked = False
        ElseIf Lines(3) = "min_style" Then
            GroupBox1.Visible = False
            GroupBox2.Visible = False
            GroupBox3.Visible = False

            DataGridView1.Top = GroupBox1.Top
            DataGridView1.Height = 323
            CheckBox3.Checked = True
        End If

        If Lines(4) = "dont_kill" Then
            CheckBox4.Checked = False
        ElseIf Lines(4) = "kill" Then
            CheckBox4.Checked = True
        End If

        System.IO.File.WriteAllLines(Application.StartupPath & "\options.ini", Lines)

        '----------------< Other functions >----------------------

        DataGridView1.AllowDrop = True                          'allow drag and drop in the DataGridView1
        PictureBox1.AllowDrop = True                            'allow drag and drop in the PictureBox1

        DataGridView1.RowHeadersVisible = False                 'hide first column
        DataGridView1.Columns(0).Width = DataGridView1.Width - 3    'change column width


        PictureBox1.Height = DataGridView1.Height - 10
        PictureBox1.Width = PictureBox1.Height
        PictureBox1.Top = DataGridView1.Height / 2 - PictureBox1.Height / 2 + DataGridView1.Top
        PictureBox1.Left = DataGridView1.Width / 2 - PictureBox1.Width / 2
    End Sub

    Private Sub Form1_SizeChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.SizeChanged
        '----------------< Change main window configs >----------------------
        DataGridView1.Width = Me.Width - 40
        DataGridView1.Columns(0).Width = DataGridView1.Width - 3    'change column width
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        '----------------< Add all files to datagridview >----------------------
        OpenFileDialog1.Multiselect = True
        OpenFileDialog1.Title = "qrcp_WinGUI"
        Dim files() As String

        If OpenFileDialog1.ShowDialog() = DialogResult.OK Then
            DataGridView1.Rows.Clear()                              'remove all rows
            files = OpenFileDialog1.FileNames
            For Each file In files
                DataGridView1.Rows.Add(file)
            Next
        Else
        End If
    End Sub

    Private Sub Button2_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        '----------------< Add folder to datagridview >----------------------
        FolderBrowserDialog1.Description = "qrcp_WinGUI"

        If (FolderBrowserDialog1.ShowDialog() = DialogResult.OK) Then
            DataGridView1.Rows.Clear()                              'remove all rows
            DataGridView1.Rows.Add(FolderBrowserDialog1.SelectedPath)
        End If
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        '----------------< Start sending the file(s)/folder >----------------------
        If DataGridView1.RowCount = 0 Then Exit Sub

        Dim Files1 As String = ""
        Dim Files2 As String = ""
        Dim ZipTemp As String = ""
        Dim Keep_Alive As String = ""

        If CheckBox1.Checked = True Then ZipTemp = "--zip "
        If CheckBox2.Checked = True Then
            Keep_Alive = "--keep-alive "
        End If

        For i = 0 To DataGridView1.RowCount - 1                         'create string with all files

            Files1 = DataGridView1.Item(0, i).Value
            Files2 = Files2 & " " & Files1 & " "
        Next

        Dim CMDcommand As String = "qrcp.exe " & ZipTemp & Keep_Alive & Files2                  'create cmd command
        Process.Start("cmd.exe", "/K " & CMDcommand)
    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        If Not System.IO.Directory.Exists(TextBox1.Text) Then               'if folder not exist 
            System.IO.Directory.CreateDirectory(TextBox1.Text)              'create this folder
            Process.Start(TextBox1.Text)
        Else
            Process.Start(TextBox1.Text)
        End If
    End Sub

    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click
        If (FolderBrowserDialog1.ShowDialog() = DialogResult.OK) Then
            TextBox1.Text = FolderBrowserDialog1.SelectedPath

            '----------- Save new option ---------------------------------------
            Dim Lines() As String = System.IO.File.ReadAllLines(Application.StartupPath & "\options.ini")
            Lines(2) = TextBox1.Text
            System.IO.File.WriteAllLines(Application.StartupPath & "\options.ini", Lines)

        End If
    End Sub

    Private Sub Button6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button6.Click
        '----------------< Start receive the file(s) >----------------------
        If Not System.IO.Directory.Exists(TextBox1.Text) Then               'if folder not exist 
            System.IO.Directory.CreateDirectory(TextBox1.Text)              'create this folder
        End If

        Dim CMDcommand As String = "qrcp receive --output=" & TextBox1.Text                   'create cmd command
        Process.Start("cmd.exe", "/K " & CMDcommand)

    End Sub

    Private Sub Button7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button7.Click
        If DataGridView1.RowCount = 0 Then
            PictureBox1.Visible = True                                                                                         'make drag and drop image visible after last row was removed
            Exit Sub 'if no files in DatGrid then exit sub
        End If
        DataGridView1.Rows.RemoveAt(DataGridView1.CurrentRow.Index)                                                            'remove row with the file
        If DataGridView1.RowCount = 0 Then
            PictureBox1.Visible = True                                                                                         'make drag and drop image visible after last row was removed
        End If
    End Sub

    Private Sub Button8_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button8.Click
        PictureBox1.Visible = True                              'make drag and drop image visible
        DataGridView1.Rows.Clear()                              'remove all rows
    End Sub

    Private Sub CheckBox1_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBox1.CheckedChanged
        '----------------< Save new options >----------------------
        Dim Lines() As String = System.IO.File.ReadAllLines(Application.StartupPath & "\options.ini")

        If CheckBox1.Checked = True Then
            Lines(0) = "zip"
        Else
            Lines(0) = "not_zip"
        End If

        System.IO.File.WriteAllLines(Application.StartupPath & "\options.ini", Lines)
    End Sub

    Private Sub CheckBox2_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBox2.CheckedChanged
        '----------------< Save new options >----------------------
        Dim Lines() As String = System.IO.File.ReadAllLines(Application.StartupPath & "\options.ini")

        If CheckBox2.Checked = True Then
            Lines(1) = "alive"
        Else
            Lines(1) = "not_alive"
        End If

        System.IO.File.WriteAllLines(Application.StartupPath & "\options.ini", Lines)
    End Sub

    Private Sub DataGridView1_DragDrop(ByVal sender As Object, ByVal e As System.Windows.Forms.DragEventArgs) Handles DataGridView1.DragDrop
        If GroupBox1.Visible = False Then DataGridView1.Rows.Clear() 'for maximalist style

        '----------------< Drag and Drop file(s) >----------------------
        Dim files() As String = e.Data.GetData(DataFormats.FileDrop)
        Dim i As Integer = 1
        For Each file In files
            DataGridView1.Rows.Add(file)
        Next

        PictureBox1.Visible = False                             'unvisible image

        If GroupBox1.Visible = False Then
            '----------------< DoubleClick to start receive the file(s) >----------------------
            Button3_Click(Nothing, Nothing)                     'activate Button3
        End If

    End Sub

    Private Sub DataGridView1_DragEnter(ByVal sender As Object, ByVal e As System.Windows.Forms.DragEventArgs) Handles DataGridView1.DragEnter
        '----------------< Drag and Drop file(s) >----------------------
        If e.Data.GetDataPresent(DataFormats.FileDrop) Then
            e.Effect = DragDropEffects.Copy
        End If
    End Sub

    Private Sub PictureBox1_DragDrop(ByVal sender As Object, ByVal e As System.Windows.Forms.DragEventArgs) Handles PictureBox1.DragDrop
        If GroupBox1.Visible = False Then DataGridView1.Rows.Clear() 'for maximalist style

        '----------------< Drag and Drop file(s) >----------------------
        Dim files() As String = e.Data.GetData(DataFormats.FileDrop)
        Dim i As Integer = 1
        For Each file In files
            DataGridView1.Rows.Add(file)
        Next

        PictureBox1.Visible = False                             'unvisible image

        If GroupBox1.Visible = False Then
            '----------------< DoubleClick to start receive the file(s) >----------------------
            Button3_Click(Nothing, Nothing)                     'activate Button3
        End If
    End Sub

    Private Sub PictureBox1_DragEnter(ByVal sender As Object, ByVal e As System.Windows.Forms.DragEventArgs) Handles PictureBox1.DragEnter
        '----------------< Drag and Drop file(s) >----------------------
        If e.Data.GetDataPresent(DataFormats.FileDrop) Then
            e.Effect = DragDropEffects.Copy
        End If
    End Sub

    Private Sub DataGridView1_DoubleClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles DataGridView1.DoubleClick
        '----------------< DoubleClick to start receive the file(s) >----------------------
        Button6_Click(Nothing, Nothing)                     'activate Button6
    End Sub

    Private Sub MinMaximalisToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MinMaximalisToolStripMenuItem.Click
        '----------------< Save new options >----------------------
        Dim Lines() As String = System.IO.File.ReadAllLines(Application.StartupPath & "\options.ini")

        If CheckBox3.Checked = False Then
            CheckBox3.Checked = True

            Lines(3) = "min_style"

            GroupBox1.Visible = False
            GroupBox2.Visible = False
            GroupBox3.Visible = False

            DataGridView1.Top = GroupBox1.Top
            DataGridView1.Height = 323

        Else
            CheckBox3.Checked = False

            Lines(3) = "max_style"

            GroupBox1.Visible = True
            GroupBox2.Visible = True
            GroupBox3.Visible = True

            DataGridView1.Top = 138
            DataGridView1.Height = 212

        End If

        PictureBox1.Height = DataGridView1.Height - 10
        PictureBox1.Width = PictureBox1.Height
        PictureBox1.Top = DataGridView1.Height / 2 - PictureBox1.Height / 2 + DataGridView1.Top
        PictureBox1.Left = DataGridView1.Width / 2 - PictureBox1.Width / 2

        System.IO.File.WriteAllLines(Application.StartupPath & "\options.ini", Lines)
    End Sub

    Private Sub KillCmdWithoutFocusToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles KillCmdWithoutFocusToolStripMenuItem.Click
        '----------------< (No)Kill cmd options >----------------------
        Dim Lines() As String = System.IO.File.ReadAllLines(Application.StartupPath & "\options.ini")

        If CheckBox4.Checked = False Then
            CheckBox4.Checked = True
            Lines(4) = "kill"
        Else
            CheckBox4.Checked = False
            Lines(4) = "dont_kill"
        End If

        System.IO.File.WriteAllLines(Application.StartupPath & "\options.ini", Lines)
    End Sub

    Private Sub NoKillCmdWithoutFocusToolStripMenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NoKillCmdWithoutFocusToolStripMenuItem1.Click
        KillCmdWithoutFocusToolStripMenuItem_Click(Nothing, Nothing)       'go to KillCmdWithoutFocusToolStripMenuItem_Click
    End Sub

    Private Sub QrcpToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles QrcpToolStripMenuItem.Click
        '----------------< Open qrcp github page >----------------------
        Try
            Dim webAddress As String = "https://github.com/claudiodangelis/qrcp"
            Process.Start(webAddress)
        Catch ex As Exception
            MsgBox("qrcp_WinGUI could not find the default browser. Here is the link for you!" & vbCrLf & vbCrLf & "https://github.com/claudiodangelis/qrcp")
        End Try
    End Sub

    Private Sub QrcpWinGUIToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles QrcpWinGUIToolStripMenuItem.Click
        '----------------< Open qrcp_WinGUI github page >----------------------
        Try
            Dim webAddress As String = "https://github.com/testertv/qrcp_WinGUI.github.io"
            Process.Start(webAddress)
        Catch ex As Exception
            MsgBox("qrcp_WinGUI could not find the default browser. Here is the link for you!" & vbCrLf & vbCrLf & "https://github.com/testertv/qrcp_WinGUI.github.io")
        End Try
    End Sub

    Private Sub AboutToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AboutToolStripMenuItem.Click
        Form2.Show()                                    'open About windows
    End Sub
End Class
